rules: {
  'linebreak-style': 0 // Desactiva la regla
  // o
  //'linebreak-style': ['error', 'windows'] // Para permitir CRLF
}
